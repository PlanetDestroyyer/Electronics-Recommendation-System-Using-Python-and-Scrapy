This Project is Electronic Item Recommendition system built by web scrapping from amazon and using streamlit
